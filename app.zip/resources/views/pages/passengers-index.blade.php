@extends('../layout/' . $layout, [
    'breadcrumb' => [
        [
            'title' => 'Passengers',
            'url' => route('passengers.index')
        ],
        [
            'title' => 'Index',
            'url' => '#'
        ]
    ]
])

@section('subhead')
    <title>Dashboard - {{ config('app.name') }}</title>
@endsection

@section('subcontent')

    @include('pages.includes.session-flash-message-notification')







@endsection
