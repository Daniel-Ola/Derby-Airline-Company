<?php $__env->startSection('subhead'); ?>
    <title>Dashboard - <?php echo e(config('app.name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>

    <?php echo $__env->make('pages.includes.session-flash-message-notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/' . $layout, [
    'breadcrumb' => [
        [
            'title' => 'Passengers',
            'url' => route('passengers.index')
        ],
        [
            'title' => 'Index',
            'url' => '#'
        ]
    ]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Documents\__\Apps\Work\Derby Airline Company\_src\resources\views/pages/passengers-index.blade.php ENDPATH**/ ?>