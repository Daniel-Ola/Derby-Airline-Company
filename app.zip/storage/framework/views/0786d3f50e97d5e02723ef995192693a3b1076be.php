<?php
    $status = $flight->status;
    $disable_functions = ($status == 'completed' || $status == 'in-progress');
?>

<?php $__env->startSection('subhead'); ?>
    <title>Flight Management - <?php echo e(config('app.name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>

    <?php echo $__env->make('pages.includes.session-flash-message-notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div>

        <div class="intro-y col-span-12 md:col-span-6">
            <div class="box">
                <div class="flex flex-col lg:flex-row items-center p-5 border-b border-gray-200 dark:border-dark-5">
                    <div class="lg:ml-2 lg:mr-auto text-center lg:text-left mt-3 lg:mt-0">
                        <a href="#" class="font-medium">Select Crew Members</a>
                        <div class="text-gray-600 text-xs mt-0.5">Flight <?php echo e($flight->flightnum); ?></div>
                    </div>
                    <div class="flex -ml-2 lg:ml-0 lg:justify-end mt-3 lg:mt-0">
                        <a href="?update_status=waiting" class="w-8 h-8 rounded-full flex items-center justify-center border dark:border-dark-5 ml-2 text-gray-500 zoom-in tooltip" title="Waiting">
                            <?php if($flight->status == 'waiting'): ?>
                                <i class="w-3 h-3" data-feather="check-circle"></i>
                            <?php else: ?>
                                <i class="w-3 h-3" data-feather="minus-circle"></i>
                            <?php endif; ?>
                        </a>
                        <a href="?update_status=in-progress" class="w-8 h-8 rounded-full flex items-center justify-center border dark:border-dark-5 ml-2 text-gray-500 zoom-in tooltip" title="In progress">
                            <?php if($flight->status == 'in-progress'): ?>
                                <i class="w-3 h-3" data-feather="check-circle"></i>
                            <?php else: ?>
                                <i class="w-3 h-3" data-feather="minus-circle"></i>
                            <?php endif; ?>
                        </a>
                        <a href="?update_status=completed" class="w-8 h-8 rounded-full flex items-center justify-center border dark:border-dark-5 ml-2 text-gray-500 zoom-in tooltip" title="Completed">
                            <?php if($flight->status == 'completed'): ?>
                                <i class="w-3 h-3" data-feather="check-circle"></i>
                            <?php else: ?>
                                <i class="w-3 h-3" data-feather="minus-circle"></i>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
                <div class="flex flex-wrap lg:flex-nowrap items-center justify-center p-5 w-full">


                    <div class="grid grid-cols-12 gap-12 mt-5">
                        <div class="intro-y col-span-12 lg:col-span-12">
                            <!-- BEGIN: Form Layout -->
                            <div class="intro-y box p-5 border-dark-3">
                                <form action="<?php echo e(route('do.flights.manage', [$flight->flightnum])); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php if(! $has_crew_members): ?>
                                        <div class="mt-3">
                                            <label for="crud-form-1" class="form-label">Pilot</label>
                                            <select data-placeholder="Select Pilot" class="tom-select w-full bg-danger" id="crud-form-1" name="empnum[]">
                                                <?php $__empty_1 = true; $__currentLoopData = $pilots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php
                                                        $staff = $pilot->staffs;
                                                    ?>
                                                    <option value="<?php echo e($staff->empnum); ?>"><?php echo e($staff->full_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option value="">There are no qualified pilots available</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="mt-3">
                                            <label for="crud-form-2" class="form-label">Co-Pilot</label>
                                            <select data-placeholder="Select Pilot" class="tom-select w-full bg-danger" id="crud-form-2"  name="empnum[]">
                                                <?php $__empty_1 = true; $__currentLoopData = $co_pilots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co_pilot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($co_pilot->empnum); ?>"><?php echo e($co_pilot->full_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option value="">There are no qualified co-pilots available</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="mt-3">
                                            <label for="crud-form-3" class="form-label">Other Crew Members</label>
                                            <select data-placeholder="Select Pilot" class="tom-select w-full bg-danger" id="crud-form-3" multiple name="empnum[]">
                                                <?php $__empty_1 = true; $__currentLoopData = $crews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($crew->empnum); ?>"><?php echo e($crew->full_name . ' - ' . $crew->role->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option value>There are no qualified crew member available</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    <?php else: ?>
                                        <input type="hidden" name="has_crews" value="<?php echo e($has_crew_members); ?>">
                                        <div class="mt-3">
                                            <label for="crud-form-3" class="form-label">Update Crew Members</label>
                                            <select data-placeholder="Update Crew Members" class="tom-select w-full bg-danger" id="crud-form-3" multiple name="empnum[]">
                                                <?php $__empty_1 = true; $__currentLoopData = $other_staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($staff->empnum); ?>" <?php echo e(! in_array($staff->empnum, $crewMembers) ?: 'selected'); ?>>
                                                        <?php echo e($staff->full_name . ' - ' . $staff->role->title); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option>There are no qualified crew members available</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    <?php endif; ?>

                                    <div class="col-12 mt-3">
                                        <button class="btn btn-primary py-1 px-2 mr-2" type="submit" <?php echo e($disable_functions ? 'disabled' : ''); ?>>Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="intro-y col-span-12 md:col-span-6 md:mt-3">
            <div class="box">
                <div class="flex flex-col lg:flex-row items-center p-5 border-b border-gray-200 dark:border-dark-5">
                    <div class="lg:ml-2 lg:mr-auto text-center lg:text-left mt-3 lg:mt-0">
                        <a href="#" class="font-medium">Book flight</a>
                        <div class="text-gray-600 text-xs mt-0.5">
                            Flight <?php echo e($flight->flightnum); ?> -
                            <?php echo e((! $on_board) ?
                                                'No Booking on this flight yet' :
                                                $on_board['passengers'] . ' of ' . $on_board['capacity'] . ' seats filled'); ?>

                        </div>
                    </div>
                </div>
                <div class="flex flex-wrap lg:flex-nowrap items-center justify-center p-5 w-full">

                    <div class="grid grid-cols-12 gap-12 mt-5">
                        <div class="intro-y col-span-12 lg:col-span-12">
                            <!-- BEGIN: Form Layout -->
                            <div class="intro-y box p-5 border-dark-3">
                                <form class="validate-forms" method="post" action="<?php echo e(route('flights.book', [$flight->flightnum])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e(Auth::id()); ?>" name="user_id" readonly>
                                    <div class="input-form">
                                        <label for="validation-form-1" class="form-label w-full flex flex-col sm:flex-row"> Flight Number </label>
                                        <input id="validation-form-1" type="text" name="flightnum" class="form-control" value="<?php echo e($flight->flightnum); ?>" readonly >
                                    </div>
                                    <div class="input-form">
                                        <label for="validation-form-11" class="form-label w-full flex flex-col sm:flex-row"> Surname </label>
                                        <input id="validation-form-11" type="text" name="surname" class="form-control" placeholder="Doe" required>
                                    </div>
                                    <div class="input-form mt-3">
                                        <label for="validation-form-2" class="form-label w-full flex flex-col sm:flex-row"> Name </label>
                                        <input id="validation-form-2" type="text" name="name" class="form-control" placeholder="John" required>
                                    </div>
                                    <div class="input-form mt-3">
                                        <label for="validation-form-3" class="form-label w-full flex flex-col sm:flex-row"> Phone Number </label>
                                        <input id="validation-form-3" type="phone" name="phone" class="form-control" placeholder="+44 7911 123456" required>
                                    </div>
                                    <div class="input-form mt-3">
                                        <label for="validation-form-3-eta" class="form-label w-full flex flex-col sm:flex-row"> Passenger Address </label>
                                        <textarea id="validation-form-3-eta" class="form-control" name="address" placeholder="Type your address" minlength="10" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary mt-5" <?php echo e($disable_functions ? 'disabled' : ''); ?>>Continue</button>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


        <div class="col-12 mt-3 float-right">
            <button class="btn btn-danger py-2 px-3 text-2xl mr-2" type="submit">
                Delete Flight Schedule
            </button>
        </div>



    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/' . $layout,
    [
        'breadcrumb' => [
            [
                'title' => 'Flight Management',
                'url' => route('flights.index')
            ],
            [
                'title' => $flight->flightnum,
                'url' => '#'
            ]
        ]
    ]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Documents\__\Apps\Work\Derby Airline Company\_src\resources\views/pages/flights-manage.blade.php ENDPATH**/ ?>