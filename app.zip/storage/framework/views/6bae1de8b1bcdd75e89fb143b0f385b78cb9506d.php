<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('pages.includes.landing.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
<div class="loader-wrapper">
    <div class="loaders">
        <div class="loader-logo-pulse">
            <img src="<?php echo e(asset('dist/images/logo.svg')); ?>" alt="Derby Airline">
        </div>
        <div class="loader-1">
        </div>
    </div>
</div>

<div class="wrapper">
    <!-- Header Start -->
    <header id="menu" class="header navbar-fixed-top op-header">
        <nav class="navbar">
            <div class="container">
                <div class="menu-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="top-bar"></span>
                        <span class="middle-bar"></span>
                        <span class="bottom-bar"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <div class="nav-logo">
                        <a class="logo" href="index">
                            <img class="logo-dark" src="<?php echo e(asset('dist/landing/assets/images/logo/logo-2.png')); ?>" alt="Derby Airline">
                        </a>
                    </div>
                </div>
                <div class="collapse navbar-collapse nav-collapse">
                    <ul class="nav navbar-nav" >
                        <li class="nav-item">
                            <a class="scroll-to" href="#hero">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="scroll-to" href="#about">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="scroll-to" href="#portfolio">Portfolios</a>
                        </li>
                        <li>
                            <a class="scroll-to" href="#news">Book Flight</a>
                        </li>
                        <li class="nav-item">
                            <a class="scroll-to" href="#contact">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- Header End -->


    <!-- Hero Start -->
    <section id="hero">
        <div class="tp-banner-container">
            <div class="tp-banner rev-banner-fullscreen">
                <ul>
                    <li data-index="rs-353" data-transition="crossfade" data-slotamount="default" data-masterspeed="2000">
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-2"
                             id="slide-1-layer-1"
                             data-x="['right','right','right','right']" data-hoffset="['-700','-700','-220','-220']"
                             data-y="['center','center','center','center']" data-voffset="['40','-40','0','0']"
                             data-width="none"
                             data-height="none"
                             data-whitespace="nowrap"
                             data-transform_in="x:50;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;s:1000"
                             data-transform_idle="o:1;"
                             data-start="500"
                             data-responsive_offset="on"
                             style="z-index: 7;">
                            <img src="<?php echo e(asset('dist/landing/assets/images/airplane/plane-expanded.jpg')); ?>" alt="" data-ww="['1200','1200','450','450']" data-hh="['700','700','250','250']" data-no-retina>
                        </div>
                        <div class="tp-caption tp-resizeme secondary-font text-dark"
                             id="slide-1-layer-2"
                             data-x="['left','left','left','left']" data-hoffset="['-50','-50','15','15']"
                             data-y="['center','center','center','center']" data-voffset="['-90','-90','-100','-100']"
                             data-fontsize="['40','40','30','30']"
                             data-lineheight="['40','40','40','40']"
                             data-width="['400','356','334','277']"
                             data-height="['none','none','76','68']"
                             data-whitespace="normal"
                             data-transform_idle="o:1;"
                             data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeOut;"
                             data-start="1200"
                             data-responsive_offset="on"
                             style="z-index: 8; letter-spacing: 1px;">
                            <span class="font-secondary">Derby Airline Company</span>
                        </div>
                        <div class="tp-caption"
                             id="slide-1-layer-3"
                             data-x="['left','left','left','left']" data-hoffset="['-50','-50','15','15']"
                             data-y="['center','center','center','center']" data-voffset="['0','0','-40','-40']"
                             data-fontsize="['15','15','15','15']"
                             data-lineheight="['27','27','27','27']"
                             data-width="['500','356','250','250']"
                             data-height="['none','none','76','68']"
                             data-whitespace="normal"
                             data-transform_idle="o:1;"
                             data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeOut;"
                             data-responsive_offset="on"
                             data-start="1200"
                             style="z-index: 8;">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        </div>
                        <div class="tp-caption tp-resizeme"
                             id="slide-1-layer-4"
                             data-x="['left','left','left','left']" data-hoffset="['-50','-50','15','15']"
                             data-y="['center','center','center','center']" data-voffset="['90','90','130','130']"
                             data-transform_idle="o:1;"
                             data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeOut;"
                             data-responsive_offset="on"
                             data-start="1200"
                             style="z-index: 8; letter-spacing: 1px;">
                            <a class="btn btn-md btn-theme" href="#news">Book Flight Now! <i class="ei ei-right-arrow pdd-left-10"></i></a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <!-- Hero End -->


    <!-- About Start -->
    <section id="about" class="section-1">
        <div class="container">
            <div class="text-center">
                <p class="theme-color"><b>An Experience to call royal</b></p>
                <h2>Journey with us now</h2>
                <p class="width-50 mrg-horizon-auto mrg-top-15">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy  text ever since the 1500s</p>
            </div><!-- /text-center -->
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <img class="img-responsive mrg-horizon-auto" src="<?php echo e(asset('dist/landing/assets/images/img-3.png')); ?>" alt="">
                </div>
            </div>
            <div class="row mrg-top-70">
                <div class="col-md-4">
                    <div class="features-block-3">
                        <i class="ei ei-insurance"></i>
                        <div class="features-info">
                            <h4 class="features-tittle">Safety and Security</h4>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
                        </div><!-- /features-info -->
                    </div><!-- /features-block-3 -->
                </div>
                <div class="col-md-4">
                    <div class="features-block-3">
                        <i class="ei ei-folder-check"></i>
                        <div class="features-info">
                            <h4 class="features-tittle">Comfortability</h4>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
                        </div><!-- /features-info -->
                    </div><!-- /features-block-3 -->
                </div>
                <div class="col-md-4">
                    <div class="features-block-3">
                        <i class="ei ei-pencil"></i>
                        <div class="features-info">
                            <h4 class="features-tittle">Value</h4>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
                        </div><!-- /features-info -->
                    </div><!-- /features-block-3 -->
                </div>
            </div>
        </div>
    </section>
    <!-- About End -->


    <!-- Portfolio Start -->
    <section id="portfolio" class="section-1 bg-gray">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="stack-object-1">
                        <div class="row">
                            <div class="col-md-8 col-sm-8 col-xs-8">
                                <img class="object-1 img-responsive" src="<?php echo e(asset('dist/landing/assets/images/airplane/partners.jpg')); ?>" alt="" data-parallax='{"y": -30}'>
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-4 hidden">
                                <img class="object-2 img-responsive" src="<?php echo e(asset('dist/landing/assets/images/img-5.png')); ?>" alt="" data-parallax='{"y": 30}'>
                            </div>
                        </div>
                    </div><!-- /stacked-img -->
                </div>
                <div class="col-md-5 col-md-offset-1">
                    <h2 class="heading-1 left mrg-top-120"><span class="theme-color">Derby</span> Airline Partnership</h2>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy  text ever since the 1500s, when an unknown printer took a galley of type and scrambled it.</p>
                    <div class="mrg-top-40">
                        <a href="javascript:void(0);" class="mrg-right-10">
                            <img src="<?php echo e(asset('dist/landing/assets/images/thumb/android.png')); ?>" alt="">
                        </a>
                        <a href="javascript:void(0);">
                            <img src="<?php echo e(asset('dist/landing/assets/images/thumb/apple.png')); ?>" alt="">
                        </a>
                    </div>
                </div><!-- column -->
            </div>
        </div>
    </section>
    <!-- Portfolio End -->


    <!-- News Start -->
    <section id="news" class="section-1">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="mrg-top-30">Travellers Said</h2>
                    <div class="testimonial-3 mrg-btm-30">
                        <div class="tab-content">
                            <div id="client-1" class="active tab-pane fade in">
                                <div class="client clearfix mrg-top-30">
                                    <img class="client-img" src="<?php echo e(asset('dist/landing/assets/images/thumb/testimonial-1.jpg')); ?>" alt="">
                                    <div class="client-info">
                                        <h4 class="client-name theme-color">Carte Doe</h4>
                                        <!-- <p class="font-size-13">Apple.Inc</p> -->
                                    </div>
                                </div>
                                <p class="mrg-top-10">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.It has survived not only five centuries,</p>
                            </div>
                            <div id="client-2" class="tab-pane fade">
                                <div class="client clearfix mrg-top-30">
                                    <img class="client-img" src="<?php echo e(asset('dist/landing/assets/images/thumb/testimonial-1.jpg')); ?>" alt="">
                                    <div class="client-info">
                                        <h4 class="client-name theme-color">John Doe</h4>
                                        <p class="font-size-13">Apple.Inc</p>
                                    </div>
                                </div>
                                <p class="mrg-top-10">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.It has survived not only five centuries,</p>
                            </div>
                            <div id="client-3" class="tab-pane fade">
                                <div class="client clearfix mrg-top-30">
                                    <img class="client-img" src="<?php echo e(asset('dist/landing/assets/images/thumb/testimonial-1.jpg')); ?>" alt="">
                                    <div class="client-info">
                                        <h4 class="client-name theme-color">Snow Doe</h4>
                                        <p class="font-size-13">Apple.Inc</p>
                                    </div>
                                </div>
                                <p class="mrg-top-10">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.It has survived not only five centuries,</p>
                            </div>
                            <div id="client-4" class="tab-pane fade">
                                <div class="client clearfix mrg-top-30">
                                    <img class="client-img" src="<?php echo e(asset('dist/landing/assets/images/thumb/testimonial-1.jpg')); ?>" alt="">
                                    <div class="client-info">
                                        <h4 class="client-name theme-color">Vincent Doe</h4>
                                        <p class="font-size-13">Apple.Inc</p>
                                    </div>
                                </div>
                                <p class="mrg-top-10">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.It has survived not only five centuries,</p>
                            </div>
                        </div>
                        <div class="swiper-3 swiper-container hidden">
                            <ul class="swiper-wrapper client-tab">
                                <li class="swiper-slide active">
                                    <a data-toggle="tab" href="#client-1">
                                        <img class="img-responsive mrg-horizon-auto" src="<?php echo e(asset('dist/landing/assets/images/airplane/cheverolet-120x50.jpg')); ?>" alt="">
                                    </a>
                                </li>
                                <li class="swiper-slide">
                                    <a data-toggle="tab" href="#client-2">
                                        <img class="img-responsive mrg-horizon-auto" src="<?php echo e(asset('dist/landing/assets/images/logo/client-2.png')); ?>" alt="">
                                    </a>
                                </li>
                                <li class="swiper-slide">
                                    <a data-toggle="tab" href="#client-3">
                                        <img class="img-responsive mrg-horizon-auto" src="<?php echo e(asset('dist/landing/assets/images/logo/client-3.png')); ?>" alt="">
                                    </a>
                                </li>
                                <li class="swiper-slide">
                                    <a data-toggle="tab" href="#client-4">
                                        <img class="img-responsive mrg-horizon-auto" src="<?php echo e(asset('dist/landing/assets/images/logo/client-4.png')); ?>" alt="">
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-md-offset-2" style="background: none !important;">
                    <div class="pricing-1 recommended" data-parallax='{"y": -50}'>
                        <!-- there -->
                        <!-- <div class="col-md-8 col-md-offset-2"> -->
                        <div class="">
                            <h2>Book a Flight Now!</h2>
                            <form class="contact-form-wrapper" name="contactForm" id="contact_form" method="post" action="<?php echo e(route('flights.book.no-auth')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <select class="selectpicker" data-live-search="true" name="flightnum">
                                            <?php $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($flight['flightnum']); ?>">
                                                    <?php echo e($flight['origin']); ?> - <?php echo e($flight['dest']); ?> (Flight Number <?php echo e($flight['flightnum']); ?> )
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <input type="text" class="form-control" name="surname" placeholder="Surname">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <input type="text" class="form-control input-email fill-this" name="name" placeholder="Name">
                                    </div>
                                    <div class="form-group col-md-12">
                                        <input type="text" class="form-control" name="phone" placeholder="Phone Number">
                                    </div>
                                    <div class="form-group col-md-12">
                                        <textarea class="form-control" name="address" rows="3" placeholder="Address"></textarea>
                                    </div>
                                    <?php if($message = Session::get('message')): ?>
                                        <script>
                                            alert('<?php echo e($message); ?>');
                                        </script>
                                        <div class="form-group col-md-12">
                                            <div id="mail_success" class="success">
                                                <?php echo e($message); ?>

                                            </div>
                                            <div id="mail_fail" class="error" style="display:none;">
                                                An error occured, please try again later !
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group col-md-12" id="submit">
                                        <button class="btn btn-md btn-dark" type="submit">
                                            Book Flight
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- News End -->


    <!-- Contact Start -->
    <section id="contact">
        <div class="content-block-2">
            <div class="image-container col-md-6">
                <div class="background-holder has-content" style="background-image: url(<?php echo e(asset('dist/landing/assets/images/airplane/boarding-plane.jpg')); ?>)">
                    <div class="content">
                        <div class="row">
                            <!-- here -->
                            <div class="col-md-8 col-md-offset-2">
                                <div class="card padding-30 mrg-vertical-40">
                                    <form class="contact-form-wrapper" name="contactForm" id="contact_form" method="post" action="#">
                                        <div class="row">
                                            <div class="form-group col-md-6">
                                                <input type="text" class="form-control" name="name" placeholder="Name">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <input type="email" class="form-control input-email fill-this" name="email" placeholder="Email">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <input type="text" class="form-control" name="subject" placeholder="Subject">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <textarea class="form-control" name="message" rows="3" placeholder="Meassage"></textarea>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <div id="mail_success" class="success" style="display:none;">
                                                    Thank You ! Your email has been delivered.
                                                </div>
                                                <div id="mail_fail" class="error" style="display:none;">
                                                    An error occured, please try again later !
                                                </div>
                                            </div>
                                            <div class="form-group col-md-12" id="submit">
                                                <input class="btn btn-md btn-dark" type="submit" id="send_message" value="Send Message" disabled>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 col-md-offset-6 ">
                        <div class="text-content bg-gray">
                            <div class="mrg-btm-30">
                                <h2>Contact Us</h2>
                                <p class="width-80">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                            </div>
                            <p>
                                <b class="text-dark">Contact Number:</b>
                                <span>021-234-8888</span>
                            </p>
                            <p>
                                <b class="text-dark">Email Adress:</b>
                                <span>your@email.com</span>
                            </p>
                            <div class="row mrg-top-30">
                                <div class="col-md-9">
                                    <p class="font-size-17 text-dark"><b>Adress</b></p>
                                    <p>74 5th Avenueat St. Marks Place Brooklyn, NY 11217</p>
                                </div>
                            </div>









                            <ul class="social-btn mrg-top-30">
                                <li><a class="btn icon-btn-md btn-dark-inverse hover-facebook border-radius-round" href="javascript:void(0);"><i class="ei ei-facebook"></i></a></li>
                                <li><a class="btn icon-btn-md btn-dark-inverse hover-twitter border-radius-round" href="javascript:void(0);"><i class="ei ei-twitter"></i></a></li>
                                <li><a class="btn icon-btn-md btn-dark-inverse hover-google-plus border-radius-round" href="javascript:void(0);"><i class="ei ei-google-plus"></i></a></li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact End -->

</div>
<!-- wrapper -->


<!-- Footer Start -->
<section class="footer-default footer-reveal">
    <div class="footer-reveal-wrapper">


























































        <div class="footer-bottom">
            <div class="container">
                <span class="copyright"><img class="pdd-right-10" src="<?php echo e(asset('dist/landing/assets/images/logo/logo-3.png')); ?>" alt="Derby Airline"> Copyright © 2021  <a href="#">Derby Airline</a></span>
                <ul class="social-btn pull-right mrg-top-5">
                    <li><a href="#" class="btn btn-gray icon-btn-sm icon-btn-round"><i class="ei ei-facebook"></i></a></li>
                    <li><a href="#" class="btn btn-gray icon-btn-sm icon-btn-round"><i class="ei ei-twitter"></i></a></li>
                    <li><a href="#" class="btn btn-gray icon-btn-sm icon-btn-round"><i class="ei ei-google-plus"></i></a></li>
                    <li><a href="#" class="btn btn-gray icon-btn-sm icon-btn-round"><i class="ei ei-dribble"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- Footer End -->


<?php echo $__env->make('pages.includes.landing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\hp\Documents\__\Apps\Work\Derby Airline Company\_src\resources\views/pages/landing.blade.php ENDPATH**/ ?>