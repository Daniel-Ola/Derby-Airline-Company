<?php $__env->startSection('subhead'); ?>
    <title>Dashboard - <?php echo e(config('app.name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>

    <?php echo $__env->make('pages.includes.session-flash-message-notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="col-span-12 lg:col-span-8 xl:col-span-6 mt-5">
        <div class="intro-y block sm:flex items-center h-10">
            <h2 class="text-lg font-medium truncate mr-5">
                Flight Report
            </h2>

            <a href="<?php echo e(route('flights.create')); ?>" class="btn btn-primary shadow-md sm:ml-auto mt-3 sm:mt-0 sm:w-auto">
                Add Flight Schedule
            </a>
        </div>

        <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3">

            <?php $__empty_1 = true; $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $airplane = $flight->airplane;
                    $crewmembers = $flight->crewmembers;
                ?>
                <div class="report-box-2 intro-y mt-12 sm:mt-5">
                    <div class="box sm:flex">
                        <div class="px-8 py-12 flex flex-col justify-center flex-none">

                            <div class="w-50">
                                <?php echo $__env->make('pages.includes.flight-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                            <div class="relative text-smalls text-big font-medium mt-12 pl-4 ml-0.5">
                                <?php echo e($flight->flightnum); ?>

                            </div>
                            <div class="mt-4 text-gray-600 dark:text-gray-600">
                                <div class="mt-5">
                                    <div class="flex items-center">
                                        <div class="w-2 h-2 bg-theme-11 rounded-full mr-3"></div>
                                        <span class="truncate"><?php echo e($flight->flight_status); ?></span>
                                    </div>












                                </div>
                            </div>
                            <a href="<?php echo e(route('flights.manage', [$flight->flightnum])); ?>" class="btn btn-primary relative justify-start rounded-full mt-12 justify-center">
                                Manage
                            </a>
                        </div>
                        <div class="px-8 py-12 flex flex-col justify-center flex-1 border-t sm:border-t-0 sm:border-l border-gray-300 dark:border-dark-5 border-dashed">
                            <div class="text-gray-600 dark:text-gray-600 text-xs">ORIGIN</div>
                            <div class="mt-1.5 flex items-center">
                                <div class="text-base"><?php echo e($flight->origin); ?></div>
                            </div>
                            <div class="text-gray-600 dark:text-gray-600 text-xs mt-5">DESTINATION</div>
                            <div class="mt-1.5 flex items-center">
                                <div class="text-base"><?php echo e($flight->dest); ?></div>
                            </div>
                            <div class="text-gray-600 dark:text-gray-600 text-xs mt-5">AIRPLANE</div>
                            <div class="mt-1.5 flex items-center">
                                <div class="text-base"><?php echo e($airplane->manufacturer . ' ' . $airplane->numser); ?></div>
                            </div>
                            <div class="text-gray-600 dark:text-gray-600 text-xs mt-5">CREW</div>
                            <div class="mt-1.5 flex items-center">
                                <div class="text-base"><?php echo e($crewmembers?->count()); ?></div>
                            </div>
                            <div class="text-gray-600 dark:text-gray-600 text-xs mt-5">PASSENGERS ON-BOARD</div>
                            <div class="mt-1.5 flex items-center">
                                <div class="text-base"><?php echo e($flight->passengers->count()); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div class="report-box-2 intro-y mt-12 sm:mt-5 col-start-2 col-span-1">
                    <div class="box sm:flex">
                        <div class="px-8 py-12 flex flex-col justify-center flex-1 items-stretch">

                            <div class="grid grid-cols-3 w-1/2">
                                <div class="col-start-3 w-full justify-items-center">
                                    <?php echo $__env->make('pages.includes.flight-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>

                            <div class="relative text-3xl font-medium mt-12 pl-4 ml-0.5">
                                No Flight Schedule
                            </div>
                            <a href="<?php echo e(route('flights.create')); ?>" class="btn btn-outline-secondary relative justify-start rounded-full mt-12">
                                Create Flight Schedule
                            </a>
                        </div>
                    </div>
                </div>

            <?php endif; ?>

            <div class="mt-5">
                <?php echo e($flights->links()); ?>

            </div>

        </div>

    </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Documents\__\Apps\Work\Derby Airline Company\_src\resources\views/pages/fights-index.blade.php ENDPATH**/ ?>