<?php

namespace App\Exceptions;

use Exception;

class StaffException extends Exception
{
    //
}
