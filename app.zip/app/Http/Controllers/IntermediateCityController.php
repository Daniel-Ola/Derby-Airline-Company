<?php

namespace App\Http\Controllers;

use App\Models\IntermediateCity;
use Illuminate\Http\Request;

class IntermediateCityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\IntermediateCity  $intermediateCity
     * @return \Illuminate\Http\Response
     */
    public function show(IntermediateCity $intermediateCity)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\IntermediateCity  $intermediateCity
     * @return \Illuminate\Http\Response
     */
    public function edit(IntermediateCity $intermediateCity)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\IntermediateCity  $intermediateCity
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, IntermediateCity $intermediateCity)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\IntermediateCity  $intermediateCity
     * @return \Illuminate\Http\Response
     */
    public function destroy(IntermediateCity $intermediateCity)
    {
        //
    }
}
